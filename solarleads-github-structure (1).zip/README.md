# SolarLeads KI-System

Systemstruktur, Module, GPT-Prompts und Architektur gemäß SPEC-1.